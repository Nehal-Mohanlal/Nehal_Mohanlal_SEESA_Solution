﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.


/////////// Final Solution /////////////////


// iterate 1 to 100 
for (let i = 1; i <= 100; i++) {

    // conditions
    if (i % 3 == 0 && i % 5 == 0) {
        document.write("\nFizzBuzz ") 
    }
    else if (i % 3 == 0) {
        document.write("\nFizz ") 
    }
    else if (i % 5 == 0) {
        document.write("\nBuzz" + i) 
    }
    else {
        document.write("\n " + i) 
    }; 
    

}



// tested logic on the Console first. 
//for (let i = 1; i <= 100; i++) {

//    // conditions
//    if (i % 3 == 0 && i % 5 == 0) {
//        console.log("\nFizzBuzz")
//    }
//    else if (i % 3 == 0) {
//        console.log("\nFizz")
//    }
//    else if (i % 5 == 0) {
//       console.log("\nBuzz " + i)
//    }
//    else {
//        console.log("\n" + i)
//    };


//}

